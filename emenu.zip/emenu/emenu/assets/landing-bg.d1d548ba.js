var e="/kpos/emenu/assets/landing-bg.f599644e.jpg";export{e as p};
